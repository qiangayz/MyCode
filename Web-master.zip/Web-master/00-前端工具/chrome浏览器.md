

### show user agent shadow DOM

![](http://img.smyhvae.com/20180206_1610.png)


![](http://img.smyhvae.com/20180206_1616.png)

把上图中的红框部分打钩。





