<!DOCTYPE html>
<html>
<body>

<?php
echo "我的第一段 PHP 脚本";
?>

</body>
</html>